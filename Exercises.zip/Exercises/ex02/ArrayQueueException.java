
public class ArrayQueueException extends RuntimeException {
    public ArrayQueueException(){};
    public ArrayQueueException(String msg){super(msg);}
}
