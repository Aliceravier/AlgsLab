Exercise 2

The exercise is in two parts.

Part 1 is described in the file readmeA.txt

Part 2 is described in the file readmeB.txt