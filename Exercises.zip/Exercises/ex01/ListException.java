

public class ListException extends RuntimeException {
  public ListException(){}
  public ListException(String msg){super(msg);}
}
